# Mehmed_Tukulic_Web_2019_SPRING
proposal

ShishaTime

Project Description :

Shisha Time is an app where users can find the nearest shisha bars based on their location.
There is admin panel, through which an admin can add shisha bars ( location , photos , Description ...)
Users that are logged in through facebook can rate and review those bars , and can take a participation
in giveaways that those shisha bars will post in special section called SMOKE FREE.

News feed with shisha bars promotion - managed by admin


Technical Aspects :

Entities : User, Admin , Shisha bars , giveaways , news feed

User (facebook account, avatar)

Admin (Username , password)

Shisha bars (Name, location , Happy hours, Working hours , flavours , review/rate section , prices)

giveaways(shisha bar name , duration , maximum capacity ...)

news feed ( content , created , duration , author)
