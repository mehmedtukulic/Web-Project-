<?php
require_once '../vendor/autoload.php';
require_once 'PersistanceManager.class.php';
require_once 'Config.class.php';
require_once 'util.php';
use \Firebase\JWT\JWT;

Flight::register('pm', 'PersistanceManager', [Config::DB]);

Flight::route('/', function(){
    echo 'hello world!';
});

Flight::route('GET /users', function(){
//  $data = apache_request_headers(); //get requests
//  Util::autorizacija($data);
  $users = Flight::pm()->get_all_users();
  Flight::json($users);
});

Flight::route('DELETE /users/@id', function($id){
  $data = apache_request_headers(); //get requests
  Util::autorizacija($data);
  Flight::pm()->delete_user($id);
});

Flight::route('POST /users', function(){
//  $data = apache_request_headers(); //get requests
//  Util::autorizacija($data);
  $request = Flight::request();
  $user = [
    'bar_name' => $request->data->bar_name,
    'owner_name' => $request->data->owner_name,
    'owner_contact' => $request->data->owner_contact,
    'add_date' => $request->data->add_date,
    'rata' => $request->data->rata
  ];
  Flight::pm()->add_user($user);
  Flight::redirect('../index.html#dashboard');
});

Flight::route('POST /admins/login', function(){
     $data = Flight::request()->data->getData(); //get submitted data
     $user = Flight::pm()->get_admin($data); //get user from db
     /* if a valid user was found, authenticate with JWT token */
     if ($user["status"] == "success") {
       unset($user["password"]);
       unset($user["status"]);
       $token = array(
      "user" => $user,
      "iat" => time(),
      "exp" => time() + 2592000);
       $jwt = JWT::encode($token, Config::JWT_SECRET); //create jwt
       $user['admins_token'] = $jwt; //store jwt to user array
       Flight::json($user); //return user
     } else {
       Flight::json('Unknown user');
       //alertuj();
     }
});

Flight::route('POST /reklame', function(){
//  $data = apache_request_headers(); //get requests
//  Util::autorizacija($data);
  $request = Flight::request();
  $reklama = [
    'bar_name' => $request->data->bar_name,
    'image_path' => $request->data->image_path
  ];
  Flight::pm()->add_reklamu($reklama);
  Flight::redirect('../index.html#adds');
});

Flight::route('GET /reklame', function(){
  //$data = apache_request_headers(); //get requests
  //Util::autorizacija($data);
  $adds = Flight::pm()->get_all_adds();
  Flight::json($adds);
});

Flight::route('DELETE /reklame/@id', function($id){
  //$data = apache_request_headers(); //get requests
  //Util::autorizacija($data);
  Flight::pm()->delete_reklamu($id);
});

Flight::route('POST /dani', function(){
//  $data = apache_request_headers(); //get requests
//  Util::autorizacija($data);
  $request = Flight::request();
  $giveaway = [
    'bar_name' => $request->data->bar_name,
    'dan_name' => $request->data->dan
  ];

  Flight::pm()->add_pon($giveaway);
  Flight::redirect('../index.html#giveaway');

});

Flight::route('GET /giveaways', function(){
//  $data = apache_request_headers(); //get requests
//  Util::autorizacija($data);
  $users = Flight::pm()->get_all_giveaways();
  Flight::json($users);
});
Flight::start();

?>
