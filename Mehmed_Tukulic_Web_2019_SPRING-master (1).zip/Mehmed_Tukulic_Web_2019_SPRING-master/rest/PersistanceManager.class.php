<?php
class PersistanceManager{
  private $pdo;

  public function __construct($params){
    $this->pdo = new PDO('mysql:host='.$params['host'].';dbname='.$params['scheme'], $params['username'], $params['password']);
    $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
  }

  public function add_user($user){
    $query = "INSERT INTO users
            (bar_name,
             owner_name,
             owner_contact,
             add_date,
             rata)
            VALUES (:bar_name,
                    :owner_name,
                    :owner_contact,
                    :add_date,
                    :rata)";
    $statement = $this->pdo->prepare($query);
    $statement->execute($user);
  }

  public function get_all_users(){
    $query = "SELECT * FROM users";
    return $this->pdo->query($query)->fetchAll();
  }

  public function get_user_by_id($id){

  }

  public function update_user($id, $user){

  }

  public function delete_user($id){
    $query = "DELETE FROM users WHERE id = ?";
    $statement = $this->pdo->prepare($query);
    $statement->execute([$id]);
  }

  public function get_admin($user){
     $stmt = $this->pdo->prepare("SELECT * FROM admins WHERE email = :email AND password = :password;");
     $stmt->execute(array(
     "email" => $user["email"],
     "password" => $user["password"],
     ));
     $response = $stmt->fetch();
     if($response){
     if ($user["password"] == $response["password"]) print_r($user);
     $response["status"] = "success";
     return $response;
 // }
 }
 }

 public function add_reklamu($reklama){
   $query = "INSERT INTO reklame
           (bar_name,
            image_path)
           VALUES (:bar_name,
                   :image_path
                   )";
   $statement = $this->pdo->prepare($query);
   $statement->execute($reklama);
 }

 public function get_all_adds(){
   $query = "SELECT * FROM reklame";
   return $this->pdo->query($query)->fetchAll();
 }

 public function delete_reklamu($id){
   $query = "DELETE FROM reklame WHERE idreklame = ?";
   $statement = $this->pdo->prepare($query);
   $statement->execute([$id]);
 }

 public function add_giveaway($giveaway){

   if(dan==pon){
     $query = "INSERT INTO ponedeljak
             (bar_name)
             VALUES (:bar_name)";
   }elseif (dan==uto) {
     $query = "INSERT INTO utorak
             (bar_name)
             VALUES (:bar_name)";
   }elseif (dan==sri) {
     $query = "INSERT INTO srijeda
             (bar_name)
             VALUES (:bar_name)";
   }elseif (dan==cet) {
     $query = "INSERT INTO cetvrtak
             (bar_name)
             VALUES (:bar_name)";
   }elseif (dan==pet) {
     $query = "INSERT INTO petak
             (bar_name)
             VALUES (:bar_name)";
   }elseif (dan==sub) {
     $query = "INSERT INTO subota;
             (bar_name)
             VALUES (:bar_name)";
   }else {
     $query = "INSERT INTO nedelja
             (bar_name)
             VALUES (:bar_name)";
   }

   $statement = $this->pdo->prepare($query);
   $statement->execute($reklama);
 }

 public function add_pon($giveaway){
   $query = "INSERT INTO ponedeljak
           (bar_name)
           VALUES (:bar_name )";
   $statement = $this->pdo->prepare($query);
   $statement->execute($giveaway);
 }


}


?>
