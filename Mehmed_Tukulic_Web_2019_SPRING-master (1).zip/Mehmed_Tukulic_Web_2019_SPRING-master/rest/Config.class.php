<?php
class Config{
  const DB = [
    'host' => 'localhost:3308',
    'username' => 'root',
    'password' => 'root',
    'scheme' => 'shisha_time'
  ];

const JWT_SECRET = "WEB_PROGRAMMING";  
}
?>
