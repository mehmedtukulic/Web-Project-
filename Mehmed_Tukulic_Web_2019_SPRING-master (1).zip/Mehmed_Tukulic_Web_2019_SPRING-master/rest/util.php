<?php
use \Firebase\JWT\JWT;
class Util {

static public function autorizacija($data){

  if(isset($data['Authorization'])){ //if Authorization is passed save it to jwt variable
    $jwt = $data['Authorization'];
}
  $decoded = JWT::decode($jwt, Config::JWT_SECRET, array(
  'HS256'
  )); //decode jwt
  $decoded = json_decode(json_encode($decoded), true);
  if(!isset($decoded['user']['id'])){
  echo 'Invalid token';
  die;


}

}
}
?>
