$(document).ready(function() {


  $("#add_bar_modal").modal();

  $("main#spapp > section").height($(document).height() - 60);

  var app = $.spapp({pageNotFound : 'error_404'}); // initialize

  // define routes
  app.route({view: 'dashboard', load : 'dashboard.html' });
  app.route({view: 'giveaway', load: 'giveaway.html' });
  app.route({view: 'maps', load: 'maps.html' });
  app.route({view: 'adds', load: 'adds.html' });
  app.route({view: 'users', load: 'users.html' })
  app.route({view: 'login', load: 'login.html' })

  // run app
  app.run();



});
